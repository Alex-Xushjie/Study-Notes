---
status: cn-draft
title: IGMP Version 3
module: 04-IGMP
file: 03-IGMPv3
tags:
  - Multicast
  - IGMP
  - IGMPv3
  - Source Filtering
  - SSM
---

# 03 - IGMPv3

## 1. 本章目标

本章学习 IGMP Version 3 相比 IGMPv2 的核心扩展：

- Source Filtering；
- INCLUDE Mode 与 EXCLUDE Mode；
- Source List；
- General Query、Group-Specific Query 和 Group-and-Source-Specific Query；
- IGMPv3 Membership Report；
- Group Record；
- Current-State Record 与 State-Change Record；
- IGMPv3 与 SSM；
- 多应用状态聚合；
- IGMPv1/v2/v3 兼容机制；
- 抓包时需要检查的关键字段。

本章仍然只讨论 Receiver Host 与直连 Multicast Router 之间的三层 Membership。

IGMP Snooping 对 IGMPv3 Source List 的处理将在第 05 章中详细研究。

---

## 2. 为什么需要 IGMPv3

IGMPv1 和 IGMPv2 只能表达：

```text
I want to receive Group G.
```

例如：

```text
Join 239.1.1.1
```

但它们不能表达：

```text
Receive Group G only from Source S1.
```

也不能表达：

```text
Receive Group G from all sources except S2.
```

同一个 Group 可能存在多个 Source：

```text
Source A ─┐
          ├── Group 239.1.1.1
Source B ─┘
```

Receiver 可能只需要 Source A。

IGMPv3 因此增加：

```text
Source Filtering
```

Receiver 不再只报告 Group，而是报告：

```text
Filter Mode + Group + Source List
```

---

## 3. INCLUDE Mode

INCLUDE Mode 表示：

> 只接收 Source List 中列出的 Source 发往 Group G 的流量。

例如：

```text
Mode:   INCLUDE
Group:  232.1.1.1
Source:
- 10.1.1.10
- 10.1.1.20
```

含义：

```text
Receive:
(10.1.1.10, 232.1.1.1)
(10.1.1.20, 232.1.1.1)

Do not receive other sources for 232.1.1.1.
```

可简写为：

```text
INCLUDE {S1,S2} for G
```

### 3.1 INCLUDE 空列表

```text
INCLUDE {}
```

表示：

```text
Receive no source for Group G.
```

它通常代表该接口不再希望接收这个 Group。

---

## 4. EXCLUDE Mode

EXCLUDE Mode 表示：

> 接收所有 Source 发往 Group G 的流量，但排除 Source List 中列出的 Source。

例如：

```text
Mode:   EXCLUDE
Group:  239.1.1.1
Source:
- 10.1.1.20
```

含义：

```text
Receive all sources for 239.1.1.1
except 10.1.1.20.
```

可简写为：

```text
EXCLUDE {S2} for G
```

### 4.1 EXCLUDE 空列表

```text
EXCLUDE {}
```

表示：

```text
Receive Group G from all sources.
```

这相当于传统 ASM 的 Group Membership。

---

## 5. INCLUDE 与 EXCLUDE 对比

| Mode | Source List 的含义 | 示例 |
|---|---|---|
| INCLUDE | 只接收列表中的 Source | `INCLUDE {S1,S2}` |
| EXCLUDE | 接收列表之外的所有 Source | `EXCLUDE {S3}` |

最容易混淆的是：

```text
INCLUDE {}
→ Receive nothing

EXCLUDE {}
→ Receive from all sources
```

---

## 6. IGMPv3 与 ASM、SSM

### 6.1 ASM

传统 ASM Receiver 只指定 Group，不指定 Source。

在 IGMPv3 中通常表现为：

```text
EXCLUDE {}
```

例如：

```text
Group: 239.1.1.1
Mode:  EXCLUDE
List:  Empty
```

含义：

```text
Receive 239.1.1.1 from any source.
```

### 6.2 SSM

SSM Receiver 必须明确指定：

```text
(S,G)
```

例如：

```text
Source: 10.1.1.10
Group:  232.1.1.1
```

IGMPv3 可以表达为：

```text
INCLUDE {10.1.1.10}
for Group 232.1.1.1
```

因此：

> IGMPv3 provides the standard receiver-membership mechanism for SSM.

IGMPv3 只负责 Receiver 向 Last-Hop Router 表达 Source-specific Interest。Router 之间如何建立 `(S,G)` 转发树属于后续组播路由章节。

---

## 7. IGMPv3 报文封装

IGMPv3 直接封装在 IPv4 中：

```text
Ethernet
   ↓
IPv4
   ↓
IGMP
```

IPv4 Header：

```text
Protocol = 2
TTL      = 1
```

IGMPv3 报文应携带：

```text
IPv4 Router Alert Option
```

常见目的地址：

```text
General Query:
224.0.0.1

Group-Specific Query:
Group G

Group-and-Source-Specific Query:
Group G

IGMPv3 Membership Report:
224.0.0.22
```

---

## 8. IGMPv3 Query 格式

IGMPv3 Query 使用：

```text
Type = 0x11
```

格式如下：

```text
  0                   1                   2                   3
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |  Type = 0x11 | Max Resp Code |           Checksum            |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |                         Group Address                         |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 | Resv  |S| QRV |     QQIC      |     Number of Sources (N)     |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |                       Source Address [1]                      |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |                              ...                              |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
```

主要字段：

| Field | Meaning |
|---|---|
| Type | Query，固定为 `0x11` |
| Max Resp Code | Receiver 最长响应时间 |
| Group Address | 目标 Group |
| S | Suppress Router-side Processing |
| QRV | Querier's Robustness Variable |
| QQIC | Querier's Query Interval Code |
| Number of Sources | Source List 数量 |
| Source Address List | 被查询的 Source |

---

## 9. Max Resp Code、QRV 与 QQIC

### 9.1 Max Resp Code

当数值小于 128 时：

```text
Max Response Time
=
Max Resp Code × 0.1 second
```

例如：

```text
100 → 10 seconds
```

当数值大于或等于 128 时，使用浮点编码。

### 9.2 QRV

```text
QRV = Querier's Robustness Variable
```

默认通常为：

```text
2
```

### 9.3 QQIC

```text
QQIC = Querier's Query Interval Code
```

默认 Query Interval 通常为：

```text
125 seconds
```

---

## 10. IGMPv3 的三种 Query

### 10.1 General Query

用于询问当前接口上的全部 Group 和 Source Filter State。

```text
IPv4 Destination: 224.0.0.1
Group Address:    0.0.0.0
Number of Sources: 0
```

### 10.2 Group-Specific Query

用于询问是否仍有 Receiver 对 Group G 感兴趣。

```text
IPv4 Destination: Group G
Group Address:    Group G
Number of Sources: 0
```

### 10.3 Group-and-Source-Specific Query

用于询问是否仍有 Receiver 需要 Group G 中的特定 Source。

```text
IPv4 Destination: Group G
Group Address:    Group G
Number of Sources: N
Source List:
- S1
- S2
```

这是 IGMPv3 相比 IGMPv2 的关键扩展。

---

## 11. IGMPv3 Membership Report

IGMPv3 Membership Report 使用：

```text
Type = 0x22
```

IPv4 Destination：

```text
224.0.0.22
```

与 IGMPv1/v2 不同：

- Report 不再直接发送到所报告的 Group；
- 一个 Report 可以携带多个 Group Record；
- 每个 Group Record 可以携带 Source List。

---

## 12. IGMPv3 Report 格式

```text
  0                   1                   2                   3
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |  Type = 0x22 |    Reserved   |           Checksum            |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |           Reserved            |  Number of Group Records (M)  |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |                       Group Record [1]                        |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |                              ...                              |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |                       Group Record [M]                        |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
```

一个 Report 可以包含多个 Group Record。

---

## 13. Group Record 格式

```text
  0                   1                   2                   3
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |  Record Type  | Aux Data Len  |     Number of Sources (N)     |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |                       Multicast Address                       |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |                       Source Address [1]                      |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |                              ...                              |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
```

| Field | Meaning |
|---|---|
| Record Type | 当前状态或状态变化 |
| Aux Data Len | Auxiliary Data 长度 |
| Number of Sources | Source 数量 |
| Multicast Address | Group G |
| Source Address List | Source List |

---

## 14. 六种 Group Record Type

| Value | Record Type |
|---:|---|
| `1` | MODE_IS_INCLUDE |
| `2` | MODE_IS_EXCLUDE |
| `3` | CHANGE_TO_INCLUDE_MODE |
| `4` | CHANGE_TO_EXCLUDE_MODE |
| `5` | ALLOW_NEW_SOURCES |
| `6` | BLOCK_OLD_SOURCES |

它们分为：

```text
Current-State Record
State-Change Record
```

---

## 15. Current-State Record

用于响应 Query，报告当前 Filter State。

### 15.1 MODE_IS_INCLUDE

```text
MODE_IS_INCLUDE {Source List}
```

表示当前状态是 INCLUDE。

### 15.2 MODE_IS_EXCLUDE

```text
MODE_IS_EXCLUDE {Source List}
```

表示当前状态是 EXCLUDE。

例如：

```text
MODE_IS_EXCLUDE
Group: 239.1.1.1
Sources: Empty
```

表示接收该 Group 的所有 Source。

---

## 16. State-Change Record

用于通知 Router：Receiver 的 Filter State 发生了变化。

包括：

```text
CHANGE_TO_INCLUDE_MODE
CHANGE_TO_EXCLUDE_MODE
ALLOW_NEW_SOURCES
BLOCK_OLD_SOURCES
```

### 16.1 CHANGE_TO_INCLUDE_MODE

状态切换为：

```text
INCLUDE {Source List}
```

### 16.2 CHANGE_TO_EXCLUDE_MODE

状态切换为：

```text
EXCLUDE {Source List}
```

### 16.3 ALLOW_NEW_SOURCES

新增希望接收的 Source。

```text
Before:
INCLUDE {S1}

After:
INCLUDE {S1,S2}
```

可发送：

```text
ALLOW_NEW_SOURCES {S2}
```

### 16.4 BLOCK_OLD_SOURCES

不再希望接收某些 Source。

```text
Before:
INCLUDE {S1,S2}

After:
INCLUDE {S1}
```

可发送：

```text
BLOCK_OLD_SOURCES {S2}
```

---

## 17. Current-State 与 State-Change 的区别

| Category | Record Type | Typical Use |
|---|---|---|
| Current-State | MODE_IS_INCLUDE / MODE_IS_EXCLUDE | 响应 Query |
| State-Change | CHANGE_TO_* / ALLOW_NEW_SOURCES / BLOCK_OLD_SOURCES | Join、Leave 或 Source List 变化 |

记忆方式：

```text
MODE_IS_*
→ What is my current state?

CHANGE_TO_*
ALLOW_NEW_SOURCES
BLOCK_OLD_SOURCES
→ What has changed?
```

---

## 18. SSM 加组流程

假设应用希望接收：

```text
Source: 10.1.1.10
Group:  232.1.1.1
```

Host 建立：

```text
INCLUDE {10.1.1.10}
for 232.1.1.1
```

并发送：

```text
Destination: 224.0.0.22
Type:        0x22

Group Record:
CHANGE_TO_INCLUDE_MODE

Group:
232.1.1.1

Source:
10.1.1.10
```

后续响应 Query 时发送：

```text
MODE_IS_INCLUDE
Group: 232.1.1.1
Source: 10.1.1.10
```

---

## 19. ASM 加组流程

应用希望接收：

```text
239.1.1.1
```

并接受所有 Source。

Host 建立：

```text
EXCLUDE {}
```

并发送：

```text
CHANGE_TO_EXCLUDE_MODE
Group: 239.1.1.1
Source List: Empty
```

后续响应 Query 时报告：

```text
MODE_IS_EXCLUDE
Group: 239.1.1.1
Source List: Empty
```

---

## 20. IGMPv3 离组

### 20.1 离开 SSM Channel

当前状态：

```text
INCLUDE {S1}
```

离组后：

```text
INCLUDE {}
```

Host 可以发送：

```text
CHANGE_TO_INCLUDE_MODE
Group: G
Source List: Empty
```

### 20.2 离开 ASM Group

当前状态：

```text
EXCLUDE {}
```

离组后同样变为：

```text
INCLUDE {}
```

IGMPv3 使用 Group Record 表达离组和 Source List 变化，而不是依赖一个新的独立 Leave Message。

---

## 21. 多应用状态聚合

同一台 Host 上多个应用可能对同一 Group 提出不同请求：

```text
Application A:
INCLUDE {S1}

Application B:
INCLUDE {S2}
```

操作系统聚合后，接口级状态可能是：

```text
INCLUDE {S1,S2}
```

因此需要区分：

```text
Per-Socket Filter State
```

和：

```text
Per-Interface Filter State
```

IGMP Report 反映的是接口级聚合结果。

---

## 22. Router 端 Membership State

IGMPv3 Router 不再只维护：

```text
Interface + Group
```

还需要维护：

```text
Interface
+ Group
+ Filter Mode
+ Source State
```

例如：

```text
Interface: Ethernet0/1
Group:     232.1.1.1
Mode:      INCLUDE
Sources:
- 10.1.1.10
- 10.1.1.20
```

Router 可能维护：

- Group Filter Mode；
- Group Timer；
- Per-Source Timer；
- Source List；
- Older-Version Host Present State。

---

## 23. IGMPv3 Querier Election

IGMPv3 延续 IGMPv2 的规则：

```text
Lowest IPv4 address wins.
```

Non-Querier 仍然：

- 监听 Query；
- 监听 Report；
- 维护 Membership State；
- 运行 Other Querier Present Timer。

IGMP Querier 与 PIM DR 是不同角色。

---

## 24. IGMPv1/v2/v3 兼容

IGMPv3 Host 听到旧版本 Query 后，会进入兼容模式。

### 24.1 听到 IGMPv2 Query

Host 使用：

```text
IGMPv2 Membership Report
Type = 0x16
```

无法完整表达 Source Filter State。

### 24.2 听到 IGMPv1 Query

Host 使用：

```text
IGMPv1 Membership Report
Type = 0x12
```

同样不能表达 Source Filtering。

### 24.3 Router 发现旧版本 Host

IGMPv3 Router 收到旧版本 Report 后，会为相应 Group 维护 Older-Version Host Present State。

旧版本 Host 可能导致：

- Source Filtering 能力退化；
- Fast Leave 行为退化；
- Group 行为受最低版本限制。

部署 SSM 时必须确认：

```text
Receiver supports IGMPv3
Last-Hop Router supports IGMPv3
No version downgrade is occurring
```

---

## 25. IGMPv3 与 Report Suppression

IGMPv1/v2 的经典模型是：

```text
One host reports
Other hosts suppress their reports
```

但 IGMPv3 中，不同 Host 可能对同一个 Group 使用不同 Source List：

```text
Host A:
INCLUDE {S1}

Host B:
INCLUDE {S2}
```

一个 Host 的状态不能完整代表另一个 Host。

因此，不能把 IGMPv1/v2 的简单 Suppression 模型直接套用到所有 IGMPv3 Report。

尤其是 State-Change Report，必须根据本 Host 的状态变化可靠发送。

---

## 26. 抓包分析

### 26.1 Wireshark 过滤器

显示所有 IGMP：

```text
igmp
```

显示 Query：

```text
igmp.type == 0x11
```

显示 IGMPv3 Report：

```text
igmp.type == 0x22
```

查看发送到 IGMPv3 Router Group 的 Report：

```text
ip.dst == 224.0.0.22 and igmp.type == 0x22
```

### 26.2 General Query 检查点

| Field | Expected Value |
|---|---|
| IPv4 Destination | `224.0.0.1` |
| Protocol | `2` |
| TTL | `1` |
| Router Alert | Present |
| Type | `0x11` |
| Group Address | `0.0.0.0` |
| Number of Sources | `0` |

### 26.3 Group-Specific Query 检查点

| Field | Expected Value |
|---|---|
| IPv4 Destination | Group G |
| Type | `0x11` |
| Group Address | Group G |
| Number of Sources | `0` |

### 26.4 Group-and-Source-Specific Query 检查点

| Field | Expected Value |
|---|---|
| IPv4 Destination | Group G |
| Type | `0x11` |
| Group Address | Group G |
| Number of Sources | Greater than `0` |
| Source List | Target Sources |

### 26.5 IGMPv3 Report 检查点

| Field | Expected Value |
|---|---|
| IPv4 Destination | `224.0.0.22` |
| Protocol | `2` |
| TTL | `1` |
| Router Alert | Present |
| Type | `0x22` |
| Number of Group Records | One or more |
| Record Type | `1` to `6` |
| Multicast Address | Group G |
| Source List | Depends on Filter State |

---

## 27. 常见误解

### “IGMPv3 就是加入 `(S,G)`”

不完整。IGMPv3 同时支持 INCLUDE 和 EXCLUDE，也可以表达 ASM Membership。

### “INCLUDE 空列表表示接收所有 Source”

错误。

```text
INCLUDE {}
→ Receive nothing
```

### “EXCLUDE 空列表表示不接收任何 Source”

错误。

```text
EXCLUDE {}
→ Receive from all sources
```

### “IGMPv3 Report 发送到 Group 本身”

错误。IGMPv3 Report 发送到：

```text
224.0.0.22
```

### “一个 IGMPv3 Report 只能报告一个 Group”

错误。一个 Report 可以携带多个 Group Record。

### “MODE_IS_INCLUDE 表示状态发生变化”

错误。它是 Current-State Record。

### “IGMPv3 可以单独建立跨 Router 的 `(S,G)` Tree”

错误。IGMPv3 只表达 Receiver Interest。

### “IGMPv3 Host 一定正在使用 SSM”

错误。IGMPv3 Host 也可以使用 `EXCLUDE {}` 表达 ASM。

---

## 28. 三个版本的演进逻辑

| Version | Receiver 能表达什么 |
|---|---|
| IGMPv1 | “我需要 Group G。” |
| IGMPv2 | “我加入或离开 Group G。” |
| IGMPv3 | “我需要或排除 Group G 中的特定 Source。” |

简化理解：

```text
IGMPv1:
Group Membership

IGMPv2:
Group Membership + Faster Leave

IGMPv3:
Group Membership + Source Filtering
```

---

## 29. Chapter Summary

1. IGMPv3 的核心能力是 Source Filtering。
2. Receiver 使用 Filter Mode、Group 和 Source List 表达接收需求。
3. INCLUDE 表示只接收列表中的 Source。
4. EXCLUDE 表示接收列表之外的所有 Source。
5. `INCLUDE {}` 表示不接收任何 Source。
6. `EXCLUDE {}` 表示接收所有 Source。
7. SSM Membership 通常使用 `INCLUDE {S}`。
8. ASM Membership 通常使用 `EXCLUDE {}`。
9. IGMPv3 Query Type 仍为 `0x11`。
10. IGMPv3 定义 General、Group-Specific 和 Group-and-Source-Specific Query。
11. IGMPv3 Report Type 为 `0x22`。
12. IGMPv3 Report 发送到 `224.0.0.22`。
13. 一个 Report 可以包含多个 Group Record。
14. Current-State Record 包括 MODE_IS_INCLUDE 和 MODE_IS_EXCLUDE。
15. State-Change Record 包括 CHANGE_TO_INCLUDE_MODE、CHANGE_TO_EXCLUDE_MODE、ALLOW_NEW_SOURCES 和 BLOCK_OLD_SOURCES。
16. IGMPv3 使用 Group Record 表达 Join、Leave 和 Source List Change。
17. Host 会把多个 Socket 的接收需求聚合为 Interface-level Filter State。
18. Router 需要维护 Group Mode 和 Source State。
19. IGMPv3 延续最低 IPv4 地址成为 Querier 的规则。
20. 旧版本 Host 或 Querier 可能导致功能降级。
21. IGMPv3 只表达 Receiver Interest，不负责建立 Router 间组播树。
22. IGMP Snooping 如何处理 IGMPv3 Source List 将在第 05 章中研究。

---

## 30. References

- RFC 3376 — Internet Group Management Protocol, Version 3
- RFC 4607 — Source-Specific Multicast for IP
- RFC 2236 — Internet Group Management Protocol, Version 2
- IANA — Internet Group Management Protocol (IGMP) Type Numbers
